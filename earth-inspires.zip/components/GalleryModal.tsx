import React, { useState } from 'react';
import { X, Download, Trash2, Maximize2 } from 'lucide-react';
import { GalleryProps } from '../types';
import { Snapshot } from '../types';


export const GalleryModal: React.FC<GalleryProps> = ({ isOpen, onClose, snapshots, onDelete, theme }) => {
  const [selectedImage, setSelectedImage] = useState<Snapshot | null>(null);

  if (!isOpen) return null;

  const handleDownload = (snapshot: Snapshot) => {
    const link = document.createElement('a');
    link.href = snapshot.thumbnailDataURL;
    link.download = `earth-inspires-${snapshot.id}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  const isLight = theme === 'light';

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
      {/* Backdrop */}
      <div 
        className={`absolute inset-0 backdrop-blur-md transition-opacity duration-500 transition-colors duration-2000 ${isLight ? 'bg-slate-200/90' : 'bg-space-950/90'}`}
        onClick={onClose}
      />

      {/* Modal Content */}
      <div className={`relative w-full max-w-5xl h-[80vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden transition-colors duration-2000 ${isLight ? 'bg-white/90 border border-slate-300' : 'bg-slate-900/90 border border-slate-700'}`}>
        
        {/* Header */}
        <div className={`flex items-center justify-between p-6 border-b transition-colors duration-2000 ${isLight ? 'border-slate-200 bg-slate-50' : 'border-slate-800 bg-slate-900'}`}>
          <div>
            <h2 className={`text-2xl font-bold tracking-tight transition-colors duration-2000 ${isLight ? 'text-slate-900' : 'text-white'}`}>Exploration Gallery</h2>
            <p className={`text-sm mt-1 transition-colors duration-2000 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>{snapshots.length} discoveries logged</p>
          </div>
          <button 
            onClick={onClose}
            className={`p-2 rounded-full transition-colors duration-2000 ${isLight ? 'hover:bg-slate-200 text-slate-500 hover:text-slate-800' : 'hover:bg-slate-800 text-slate-400 hover:text-white'}`}
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Grid Content */}
        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
          {snapshots.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-500">
              <div className={`w-16 h-16 border-2 border-dashed rounded-full flex items-center justify-center mb-4 transition-colors duration-2000 ${isLight ? 'border-slate-300' : 'border-slate-700'}`}>
                <Maximize2 className="w-6 h-6 opacity-50" />
              </div>
              <p>No snapshots yet.</p>
              <p className="text-sm mt-2">Explore the map and click the camera icon.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {snapshots.map((snap) => (
                <div 
                  key={snap.id} 
                  className={`group relative aspect-square rounded-xl overflow-hidden hover:border-blue-500/50 transition-all duration-300 ${isLight ? 'bg-slate-200 border-slate-300' : 'bg-black border-slate-800'}`}
                >
                  <img 
                    src={snap.thumbnailDataURL} 
                    alt={`Snapshot ${snap.id}`} 
                    className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity group-hover:scale-105 duration-700"
                  />
                  
                  {/* Overlay Info */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
                    <p className="text-xs font-mono text-blue-400 mb-1">{snap.timestamp}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <button 
                        onClick={() => setSelectedImage(snap)}
                        className="flex-1 bg-white/10 hover:bg-white/20 backdrop-blur text-xs py-2 rounded text-white font-medium transition-colors"
                      >
                        View Full
                      </button>
                      <button 
                        onClick={() => onDelete(snap.id)}
                        className="p-2 bg-red-500/10 hover:bg-red-500/30 text-red-400 rounded transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Full Screen Viewer */}
      {selectedImage && (
        <div className="fixed inset-0 z-[110] bg-black/95 flex items-center justify-center p-4">
          <button 
            onClick={() => setSelectedImage(null)}
            className="absolute top-6 right-6 p-3 bg-white/10 hover:bg-white/20 rounded-full text-white backdrop-blur-lg transition-all"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="relative max-w-4xl w-full aspect-square md:aspect-auto md:h-[80vh] flex items-center justify-center">
            <img 
              src={selectedImage.thumbnailDataURL} 
              alt="Full view" 
              className="max-w-full max-h-full rounded-full shadow-[0_0_100px_rgba(59,130,246,0.3)]"
            />
            
            {/* Action Bar */}
            <div className="absolute bottom-[-80px] left-1/2 -translate-x-1/2 flex gap-4">
               <button 
                onClick={() => handleDownload(selectedImage)}
                className="flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-full font-medium transition-all shadow-lg shadow-blue-900/20"
              >
                <Download className="w-5 h-5" />
                Download HD
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};