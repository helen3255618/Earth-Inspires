import React, { useRef } from 'react';

interface EarthMapProps {
  isFlashing: boolean;
  theme: 'dark' | 'light';
}

export const EarthMap: React.FC<EarthMapProps> = ({ isFlashing, theme }) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Standard Satellite view, zoomed out to look like a globe
  // t=k (Satellite), z=2 (Global view), output=embed, h=off
  const mapUrl = "https://maps.google.com/maps?t=k&z=2&ll=0,0&output=embed&h=off";
  
  const isLight = theme === 'light';

  return (
    <div className="relative flex justify-center items-center w-full h-full p-4 md:p-8">
      {/* Container for shadow to create floating effect */}
      <div 
        className={`relative w-full max-w-[560px] lg:max-w-[760px] aspect-square rounded-full transition-shadow duration-4000 ${
          isLight 
            ? 'shadow-2xl shadow-black/30' 
            : 'shadow-[0_0_80px_-10px_rgba(255,255,255,0.25)]' // Subtle, transparent white glow
        }`}
      >
        {/* The Globe Container - clips the iframe and contains 3D effects */}
        <div 
          className="relative w-full h-full rounded-full overflow-hidden"
          style={{ transform: 'translateZ(0)' }} // GPU acceleration fix for radius clipping
        >
          
          {/* The Map Iframe */}
          <iframe
            ref={iframeRef}
            title="Earth Explorer"
            frameBorder="0"
            scrolling="no"
            marginHeight={0}
            marginWidth={0}
            src={mapUrl}
            className="absolute top-0 left-0 w-full h-full" // Ensure map is visible
            allowFullScreen
          />
          
          {/* Inner shadow to give the globe depth */}
          <div className="absolute inset-0 rounded-full shadow-[inset_0_0_20px_rgba(0,0,0,0.4)] pointer-events-none"></div>

          {/* Google Logo */}
          <div className="absolute bottom-5 left-1/2 -translate-x-1/2 pointer-events-none z-10">
            <span 
              className="text-white text-3xl font-sans font-medium" 
              style={{ textShadow: '0 1px 4px rgba(0,0,0,0.5)' }}
            >
              Google
            </span>
          </div>

          {/* Camera Flash Animation Layer */}
          {isFlashing && (
            <div className="absolute inset-0 bg-white z-50 animate-flash pointer-events-none"></div>
          )}
        </div>
      </div>
    </div>
  );
};